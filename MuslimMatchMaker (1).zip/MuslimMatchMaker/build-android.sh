#!/bin/bash

# Muslim Compatibility Checker - Android APK Build Script
# This script prepares the project for Android APK generation

echo "🕌 Building Muslim Compatibility Checker for Android..."

# Step 1: Install dependencies if needed
echo "📦 Installing dependencies..."
npm install

# Step 2: Build the web application
echo "🔨 Building web application..."
npm run build

# Step 3: Install Capacitor if not present
echo "📱 Setting up Capacitor for mobile..."
npm install @capacitor/core @capacitor/cli @capacitor/android --save-dev

# Step 4: Initialize Capacitor
echo "⚡ Initializing Capacitor..."
npx cap init "Muslim Compatibility Checker" "com.muslimcompatibility.app" --web-dir=dist/public

# Step 5: Add Android platform
echo "🤖 Adding Android platform..."
npx cap add android

# Step 6: Copy web assets to native project
echo "📋 Copying web assets..."
npx cap copy android

# Step 7: Sync changes
echo "🔄 Syncing changes..."
npx cap sync android

# Step 8: Open Android Studio (if available)
echo "🎯 Opening Android Studio..."
npx cap open android

echo "✅ Android build setup complete!"
echo ""
echo "📱 Next steps:"
echo "1. Open Android Studio"
echo "2. Build -> Generate Signed Bundle/APK"
echo "3. Choose APK and follow the signing process"
echo "4. Your APK will be generated in android/app/build/outputs/apk/"
echo ""
echo "🚀 Alternative: Upload to Replit Deployments for automatic APK generation"

# Make the script executable
chmod +x build-android.sh