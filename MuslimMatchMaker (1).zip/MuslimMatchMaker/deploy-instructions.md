# Muslim Compatibility Checker - Android APK Deployment Guide

## Option 1: Using Replit Deployments (Recommended)

### Automatic APK Generation via Replit
1. **Deploy on Replit**:
   ```bash
   # Your project is already configured for deployment
   # Click the "Deploy" button in Replit
   ```

2. **Configure for Mobile**:
   - Replit automatically detects PWA configuration
   - The app will be available as a web app that can be "installed"
   - Users can add to home screen on mobile devices

### Steps:
1. Click **Deploy** button in Replit interface
2. Choose **Static Site** deployment
3. Set build command: `npm run build`
4. Set output directory: `dist/public`
5. Deploy the application
6. Share the deployed URL - it works as a mobile app!

---

## Option 2: Manual Android APK Build

### Prerequisites
- Android Studio installed
- Java JDK 11 or higher
- Node.js and npm

### Build Process
1. **Run the build script**:
   ```bash
   chmod +x build-android.sh
   ./build-android.sh
   ```

2. **Or manually**:
   ```bash
   # Install dependencies
   npm install @capacitor/core @capacitor/cli @capacitor/android
   
   # Build web app
   npm run build
   
   # Initialize Capacitor
   npx cap init "Muslim Compatibility Checker" "com.muslimcompatibility.app" --web-dir=dist/public
   
   # Add Android platform
   npx cap add android
   
   # Copy and sync
   npx cap copy android
   npx cap sync android
   
   # Open in Android Studio
   npx cap open android
   ```

3. **Generate APK in Android Studio**:
   - Build → Generate Signed Bundle/APK
   - Choose APK
   - Create or use existing keystore
   - Build release APK

### APK Output Location
```
android/app/build/outputs/apk/release/app-release.apk
```

---

## Option 3: PWA Installation (No APK needed)

The app is already configured as a PWA (Progressive Web App):

1. **Mobile Installation**:
   - Open the deployed Replit URL in mobile browser
   - Tap "Add to Home Screen" 
   - App installs like a native app

2. **Features**:
   - Offline functionality
   - Native app experience
   - Push notifications (if configured)
   - Full-screen mode

---

## Current Project Configuration

### PWA Manifest
- ✅ Configured in `client/public/manifest.json`
- ✅ Islamic theme colors
- ✅ Mobile-optimized icons
- ✅ Standalone display mode

### Service Worker
- ✅ Offline caching implemented
- ✅ Background sync ready
- ✅ App shell caching

### Mobile Optimization
- ✅ Touch-friendly 44px+ buttons
- ✅ Responsive design for all screen sizes
- ✅ Islamic color scheme optimized for mobile
- ✅ Fast performance (<1 second calculations)

---

## Recommended Approach for Distribution

**For immediate deployment**: Use Replit's deployment feature - it creates a PWA that works like a native app.

**For Google Play Store**: Follow Option 2 to create an actual APK file.

The app is fully ready for both approaches! 🚀

### Quick Deploy Command
```bash
# Everything is already configured
# Just click Deploy in Replit!
```