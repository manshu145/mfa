import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const compatibilityResults = pgTable("compatibility_results", {
  id: serial("id").primaryKey(),
  partner1Name: text("partner1_name").notNull(),
  partner2Name: text("partner2_name").notNull(),
  partner1DateOfBirth: text("partner1_date_of_birth"),
  partner1BirthTime: text("partner1_birth_time"),
  partner2DateOfBirth: text("partner2_date_of_birth"),
  partner2BirthTime: text("partner2_birth_time"),
  partner1AbjadValue: integer("partner1_abjad_value").notNull(),
  partner2AbjadValue: integer("partner2_abjad_value").notNull(),
  partner1DigitalRoot: integer("partner1_digital_root").notNull(),
  partner2DigitalRoot: integer("partner2_digital_root").notNull(),
  partner1Element: text("partner1_element").notNull(),
  partner2Element: text("partner2_element").notNull(),
  nameCompatibilityScore: integer("name_compatibility_score").notNull(),
  lifePathCompatibilityScore: integer("life_path_compatibility_score"),
  overallCompatibilityScore: integer("overall_compatibility_score").notNull(),
  compatibilityLevel: text("compatibility_level").notNull(),
  insights: text("insights").notNull(),
  marriageAdvice: text("marriage_advice").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCompatibilityResultSchema = createInsertSchema(compatibilityResults).omit({
  id: true,
  createdAt: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertCompatibilityResult = z.infer<typeof insertCompatibilityResultSchema>;
export type CompatibilityResult = typeof compatibilityResults.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
