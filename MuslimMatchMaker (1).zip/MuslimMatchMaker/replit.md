# Muslim Couple Compatibility Checker

## Overview

This is a full-stack React web application that calculates compatibility between Muslim couples using Islamic numerology (Abjad/Adad calculation system). The app provides a modern, mobile-first interface with Islamic theming and includes features for calculating compatibility scores, viewing results history, and educational content about Islamic numerology.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React 18** with TypeScript for type safety and modern React patterns
- **Vite** as the build tool and development server for fast hot-reloading
- **TanStack Query** for server state management and caching
- **Wouter** for lightweight client-side routing
- **React Hook Form** with Zod validation for robust form handling
- **Tailwind CSS** with custom Islamic theming and responsive design
- **Shadcn/ui** component library for consistent, accessible UI components

### Backend Architecture
- **Express.js** server with TypeScript for API endpoints
- **RESTful API** design with proper error handling and validation
- **In-memory storage** implementation with interface for easy database swapping
- **Zod schemas** for request/response validation and type inference
- **Session management** ready with connect-pg-simple for PostgreSQL sessions

### Database Schema
- **PostgreSQL** with Drizzle ORM for type-safe database operations
- **Neon Database** integration for serverless PostgreSQL hosting
- Two main tables:
  - `users` - Basic user authentication (username/password)
  - `compatibility_results` - Stores calculation history with detailed metrics

### Authentication & Authorization
- Basic username/password authentication system structure in place
- Session-based authentication ready for implementation
- User-scoped data access patterns established

## Key Components

### Compatibility Calculation Engine
- **Abjad/Adad Calculator** - Converts names to numerical values using Islamic numerology
- **Digital Root Calculation** - Reduces numbers to single digits for elemental analysis
- **Element Mapping** - Associates digital roots with classical elements (Fire, Air, Water, Earth)
- **Compatibility Scoring** - Calculates percentage compatibility based on elemental harmony
- **Insights Generation** - Provides personalized advice and marriage guidance

### User Interface Components
- **CompatibilityForm** - Input form with name fields and optional birth data
- **ResultsDisplay** - Animated results with compatibility circles and detailed breakdowns
- **HistorySection** - Stores and displays previous calculations
- **AboutSection** - Educational content about Islamic numerology and elements

### Data Management
- **Query Client** - Centralized data fetching with caching and error handling
- **Storage Interface** - Abstracted storage layer supporting both memory and database backends
- **API Routes** - RESTful endpoints for CRUD operations on compatibility results

## Data Flow

1. **User Input** - Names and optional birth details entered through React Hook Form
2. **Validation** - Zod schemas validate input data on both client and server
3. **Calculation** - Abjad values computed, digital roots derived, elements determined
4. **Scoring** - Compatibility percentage calculated based on elemental relationships
5. **Storage** - Results saved to database with full calculation details
6. **Display** - Animated presentation of results with insights and advice
7. **History** - Previous calculations cached and displayed in history section

## External Dependencies

### UI & Styling
- **Radix UI** primitives for accessible, unstyled components
- **Tailwind CSS** for utility-first styling with custom Islamic color palette
- **Google Fonts** - Amiri, Inter, and Scheherazade New for Arabic/Islamic typography
- **Lucide React** for consistent iconography

### State Management & Data Fetching
- **TanStack Query** for server state, caching, and background updates
- **React Hook Form** with Hookform Resolvers for form state management

### Development & Build Tools
- **Vite** with React plugin and runtime error overlay for development
- **TypeScript** for static type checking across frontend and backend
- **ESBuild** for fast production builds
- **PostCSS** with Autoprefixer for CSS processing

### Backend Runtime
- **Node.js** with ES modules support
- **Express.js** with TypeScript execution via TSX
- **Drizzle Kit** for database migrations and schema management

## Deployment Strategy

### Development Environment
- **Replit** integration with custom Vite plugins for development experience
- **Hot reloading** for both frontend and backend code changes
- **Development server** combines Vite dev server with Express API

### Production Build
- **Frontend** - Vite builds optimized React bundle to `dist/public`
- **Backend** - ESBuild bundles Express server to `dist/index.js`
- **Static serving** - Express serves built frontend assets in production
- **Environment variables** - Database URLs and configuration via environment

### Progressive Web App
- **PWA manifest** configured for mobile installation
- **Service Worker** with caching strategy for offline functionality
- **Mobile-optimized** design ready for Android Studio conversion via Capacitor or similar

### Database Deployment
- **Neon Database** for serverless PostgreSQL hosting
- **Drizzle migrations** for schema versioning and deployment
- **Connection pooling** via Neon serverless driver for optimal performance

The application is architected for easy conversion to a mobile app while maintaining full web functionality. The Islamic theming, numerology calculations, and mobile-first design make it ready for deployment as both a web application and native mobile app.

## Recent Critical Fixes Implemented (January 2024)

✓ **Life Path Compatibility Display**: Enhanced compatibility calculation system with separate scores for name compatibility, life path compatibility, and overall compatibility. Results now show detailed breakdown when birth dates are provided.

✓ **Improved Color Scheme**: Implemented exact Islamic color scheme with better contrast ratios:
- Primary: Deep Navy (#1e3a8a) background
- Accent: Gold/Amber (#f59e0b) for buttons and highlights  
- Element colors: Fire (#ef4444), Water (#3b82f6), Air (#06b6d4), Earth (#84cc16)
- Enhanced readability and professional appearance

✓ **Working Share Results**: Comprehensive sharing functionality implemented:
- Copy to clipboard with fallback support
- WhatsApp direct sharing with formatted text
- Image generation and sharing using html2canvas
- Email sharing with pre-formatted content
- Native Web Share API integration with fallbacks

✓ **Mobile Optimization**: Touch-friendly design with 44px+ minimum button sizes, responsive layouts, optimized typography, and mobile-specific styling improvements.

✓ **Performance Enhancements**: Reduced calculation time to under 1 second, improved loading animations, better error handling for invalid inputs, and offline functionality with service worker.

✓ **Enhanced Results Display**: Detailed compatibility breakdown showing name compatibility, life path compatibility (when available), and overall score with visual indicators and professional formatting.