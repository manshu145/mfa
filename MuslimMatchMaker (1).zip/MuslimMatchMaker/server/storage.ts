import { users, compatibilityResults, type User, type InsertUser, type CompatibilityResult, type InsertCompatibilityResult } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Compatibility results methods
  createCompatibilityResult(result: InsertCompatibilityResult): Promise<CompatibilityResult>;
  getCompatibilityResults(): Promise<CompatibilityResult[]>;
  deleteAllCompatibilityResults(): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private compatibilityResults: Map<number, CompatibilityResult>;
  private currentUserId: number;
  private currentResultId: number;

  constructor() {
    this.users = new Map();
    this.compatibilityResults = new Map();
    this.currentUserId = 1;
    this.currentResultId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createCompatibilityResult(insertResult: InsertCompatibilityResult): Promise<CompatibilityResult> {
    const id = this.currentResultId++;
    const result: CompatibilityResult = {
      ...insertResult,
      partner1DateOfBirth: insertResult.partner1DateOfBirth || null,
      partner1BirthTime: insertResult.partner1BirthTime || null,
      partner2DateOfBirth: insertResult.partner2DateOfBirth || null,
      partner2BirthTime: insertResult.partner2BirthTime || null,
      id,
      createdAt: new Date(),
    };
    this.compatibilityResults.set(id, result);
    return result;
  }

  async getCompatibilityResults(): Promise<CompatibilityResult[]> {
    return Array.from(this.compatibilityResults.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async deleteAllCompatibilityResults(): Promise<void> {
    this.compatibilityResults.clear();
  }
}

export const storage = new MemStorage();
