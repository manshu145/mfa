import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCompatibilityResultSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all compatibility results (history)
  app.get("/api/compatibility-results", async (req, res) => {
    try {
      const results = await storage.getCompatibilityResults();
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch compatibility results" });
    }
  });

  // Create new compatibility result
  app.post("/api/compatibility-results", async (req, res) => {
    try {
      const validatedData = insertCompatibilityResultSchema.parse(req.body);
      const result = await storage.createCompatibilityResult(validatedData);
      res.status(201).json(result);
    } catch (error) {
      res.status(400).json({ message: "Invalid compatibility result data" });
    }
  });

  // Clear all compatibility history
  app.delete("/api/compatibility-results", async (req, res) => {
    try {
      await storage.deleteAllCompatibilityResults();
      res.status(200).json({ message: "All compatibility results cleared" });
    } catch (error) {
      res.status(500).json({ message: "Failed to clear compatibility results" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
