#!/bin/bash

# Muslim Compatibility Checker - Project Export Script
# This prepares your project for free deployment options

echo "🕌 Preparing Muslim Compatibility Checker for FREE Android export..."

# Step 1: Build the project
echo "🔨 Building project..."
npm run build

# Step 2: Create export package
echo "📦 Creating export package..."
mkdir -p export-package
cp -r . export-package/
cd export-package

# Step 3: Clean up unnecessary files for deployment
echo "🧹 Cleaning up for deployment..."
rm -rf node_modules
rm -rf .git
rm -f package-lock.json
rm -rf dist

# Step 4: Create deployment instructions
echo "📋 Creating deployment instructions..."
cat > DEPLOY-INSTRUCTIONS.txt << 'EOF'
MUSLIM COMPATIBILITY CHECKER - FREE DEPLOYMENT GUIDE

=== OPTION 1: GitHub Pages (Recommended) ===
1. Create GitHub repository
2. Upload all files from this folder
3. Enable GitHub Pages in repo settings
4. Use your GitHub Pages URL with PWABuilder.com to get APK

=== OPTION 2: Netlify ===
1. Go to netlify.com
2. Drag and drop this folder
3. Build command: npm run build
4. Publish directory: dist/public

=== OPTION 3: Vercel ===
1. Go to vercel.com
2. Import from GitHub or upload folder
3. Auto-deploys with correct settings

=== GET APK FROM ANY DEPLOYED URL ===
1. Go to pwabuilder.com
2. Enter your deployed URL
3. Click "Build My PWA"
4. Download Android APK (free!)

Your app includes:
- Islamic numerology (Abjad) calculator
- Life path compatibility analysis
- Professional Islamic theme (navy/gold)
- Mobile-responsive design
- Offline functionality
- Share features (WhatsApp, image, email)

All files are included and ready for deployment!
EOF

# Step 5: Build one more time to ensure everything is ready
echo "🔨 Final build..."
npm install
npm run build

echo "✅ Export package ready!"
echo ""
echo "📁 Your export-package folder contains everything needed for deployment"
echo "📋 Read DEPLOY-INSTRUCTIONS.txt for step-by-step deployment"
echo ""
echo "🚀 Recommended next steps:"
echo "1. Create GitHub repository"
echo "2. Upload export-package contents"
echo "3. Enable GitHub Pages"
echo "4. Use PWABuilder.com to create APK"
echo ""
echo "💫 Your Muslim Compatibility Checker is ready for the world!"